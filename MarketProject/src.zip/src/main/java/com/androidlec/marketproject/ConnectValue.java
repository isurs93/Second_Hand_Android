package com.androidlec.marketproject;

public class ConnectValue {
    // ip 확인 후 여기에 ip 주소를 변경해준다.
//    final public static String baseIP = "172.30.1.14";
    final public static String baseIP = "192.168.2.10";

    final public static String baseUrl = "http://"+baseIP+":8080/market/Android/";

    //final public static String baseUrl = "http://" + "192.168.200.120" + ":8080/around/";

    final public static String imageFTP = "http://"+baseIP+":8080/market/";

    final public static String imageDeviceUrl = "/data/com.androidlec.marketproject/images/";
//    http://172.30.1.14:8080/market/Android/

//    http://192.168.2.20:8080/market/20180329_195530.jpg

}